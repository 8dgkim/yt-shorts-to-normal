# yt-shorts-to-normal

This Chrome extension automatically converts YouTube Shorts to regular YouTube video user interface.


## Privacy Policy
This extension reads URLs for its functionality. It does not store any user data and is not shared with anyone.
