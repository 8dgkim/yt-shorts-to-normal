# yt-shorts-to-normal

This Chrome extension automatically converts YouTube Shorts to regular YouTube video user interface.