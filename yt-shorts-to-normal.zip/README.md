# yt-shorts-to-normal

This project is to create a Chrome extension that automatically switches YouTube Shorts to regular video interface.